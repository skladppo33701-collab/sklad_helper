import 'package:flutter/material.dart';

import '../../app/theme/app_tokens.dart';
import '../../app/widgets/frosted.dart';

/// Pixel-match demo screen (reference-inspired).
///
/// Adjustments in this version:
/// - Top buttons & chips: more "glassy / semi-transparent" (less blur, lighter tint)
/// - Open Activity: wide pill like reference
/// - FAB: small pill with glow like reference
/// - Calendar strip: still frosted + subtle dots
class ScheduleDemoScreen extends StatelessWidget {
  const ScheduleDemoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Base
          const Positioned.fill(child: ColoredBox(color: AppTokens.bgDark)),

          // Green glow (radial)
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.72, -0.95),
                  radius: 1.18,
                  colors: [
                    const Color(0xFF2C7A47).withValues(alpha: 0.62),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // Soft diagonal wash
          const Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(gradient: AppTokens.heroGradient),
            ),
          ),

          // Bottom vignette
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    AppTokens.bgDark.withValues(alpha: 0.55),
                    AppTokens.bgDark,
                  ],
                  stops: const [0.55, 0.82, 1],
                ),
              ),
            ),
          ),

          SafeArea(
            child: CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                    child: _TopBar(),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                    child: _CalendarStrip(),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
                    child: _Header(),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
                    child: _MoodChips(),
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 0),
                    child: _AgendaCard(),
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 140)),
              ],
            ),
          ),
        ],
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: const _RefFab(),
    );
  }
}

// ---------------- Top bar ----------------

class _TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _TopIconButton(icon: Icons.menu_rounded, onTap: () {}),
        const Spacer(),
        _TopIconButton(icon: Icons.more_horiz_rounded, onTap: () {}),
      ],
    );
  }
}

class _TopIconButton extends StatelessWidget {
  const _TopIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    // More semi-transparent than frosted (like your earlier preferred look)
    return InkResponse(
      onTap: onTap,
      radius: 26,
      child: Frosted(
        radius: 18,
        padding: const EdgeInsets.all(12),
        blurSigma: 10,
        borderAlpha: 0.045,
        tint: const Color(0xFF0F1415),
        child: Icon(icon, color: AppTokens.textOnDark, size: 20),
      ),
    );
  }
}

// ---------------- Calendar strip ----------------

class _CalendarStrip extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Frosted(
      radius: 30,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      blurSigma: 18,
      borderAlpha: 0.045,
      tint: const Color(0xFF0F1415),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _DayCell(day: 'M', date: '21'),
          _DayCell(day: 'T', date: '22'),
          _DayCell(day: 'W', date: '23', selected: true),
          _DayCell(day: 'T', date: '24'),
          _DayCell(day: 'F', date: '25'),
          _DayCell(day: 'S', date: '26'),
          _DayCell(day: 'S', date: '27'),
        ],
      ),
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({
    required this.day,
    required this.date,
    this.selected = false,
  });

  final String day;
  final String date;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final dayStyle = Theme.of(context).textTheme.labelSmall?.copyWith(
      color: AppTokens.textMutedOnDark,
      fontWeight: FontWeight.w700,
      letterSpacing: 0.2,
    );

    final dateStyle = Theme.of(context).textTheme.labelLarge?.copyWith(
      color: selected ? AppTokens.textOnDark : AppTokens.textMutedOnDark,
      fontWeight: FontWeight.w800,
    );

    return SizedBox(
      width: 40,
      child: Column(
        children: [
          Text(day, style: dayStyle),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: selected
                  ? Colors.white.withValues(alpha: 0.10)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(16),
              border: selected
                  ? Border.all(color: Colors.white.withValues(alpha: 0.07))
                  : null,
            ),
            child: Text(date, style: dateStyle),
          ),
          const SizedBox(height: 7),
          Container(
            width: 4,
            height: 4,
            decoration: BoxDecoration(
              color: selected
                  ? AppTokens.accentGreen
                  : Colors.white.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------- Header ----------------

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '26',
              style: Theme.of(context).textTheme.displaySmall?.copyWith(
                color: AppTokens.textOnDark,
                fontWeight: FontWeight.w900,
                height: 0.95,
              ),
            ),
            const SizedBox(width: 8),
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                'Sunday',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppTokens.textOnDark,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Icon(
              Icons.wb_cloudy_outlined,
              size: 16,
              color: AppTokens.textMutedOnDark,
            ),
            const SizedBox(width: 6),
            Text(
              '6° • Krakow',
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: AppTokens.textMutedOnDark,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Text(
          'Good morning.',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            color: AppTokens.textOnDark,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'You have 2 events,\n2 meetings and\n3 tasks today.',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            color: AppTokens.textMutedOnDark,
            fontWeight: FontWeight.w700,
            height: 1.25,
          ),
        ),
      ],
    );
  }
}

// ---------------- Mood chips ----------------

class _MoodChips extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _Chip(text: 'Great', icon: Icons.wb_sunny_outlined),
        const SizedBox(width: 10),
        _Chip(text: 'Typical', icon: Icons.blur_on_outlined),
        const SizedBox(width: 10),
        _Chip(text: 'Good', icon: Icons.nightlight_outlined),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.text, required this.icon});

  final String text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Frosted(
      radius: 999,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      blurSigma: 10,
      borderAlpha: 0.05,
      tint: const Color(0xFF0F1415),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: AppTokens.textMutedOnDark),
          const SizedBox(width: 8),
          Text(
            text,
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
              color: AppTokens.textOnDark,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------- Agenda ----------------

class _AgendaCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Frosted(
          radius: 30,
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
          blurSigma: 20,
          borderAlpha: 0.045,
          tint: const Color(0xFF0F1415),
          child: Column(
            children: const [
              _AgendaItem(
                title: 'Finish onboarding',
                subtitle: 'was overdue and\nrescheduled for yesterday',
                icon: Icons.check_circle_outline,
                accent: true,
              ),
              SizedBox(height: 14),
              // const-safe divider (white @ ~6% alpha)
              Divider(height: 1, color: Color(0x0FFFFFFF)),
              SizedBox(height: 14),
              _AgendaItem(
                title: 'Order protein and book flight tickets',
                subtitle: 'were auto-scheduled from to do',
                icon: Icons.shopping_bag_outlined,
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        // Wide pill button like reference
        SizedBox(
          width: double.infinity,
          child: InkWell(
            borderRadius: BorderRadius.circular(999),
            onTap: () {},
            child: Frosted(
              radius: 999,
              padding: const EdgeInsets.symmetric(vertical: 16),
              blurSigma: 12,
              borderAlpha: 0.05,
              tint: const Color(0xFF0F1415),
              child: Text(
                'Open Activity',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: AppTokens.textOnDark,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _AgendaItem extends StatelessWidget {
  const _AgendaItem({
    required this.title,
    required this.subtitle,
    required this.icon,
    this.accent = false,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final bool accent;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: accent
                ? AppTokens.accentGreen.withValues(alpha: 0.18)
                : Colors.white.withValues(alpha: 0.06),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: accent
                  ? AppTokens.accentGreen.withValues(alpha: 0.22)
                  : Colors.white.withValues(alpha: 0.06),
            ),
          ),
          child: Icon(
            icon,
            size: 18,
            color: accent ? AppTokens.accentGreen : AppTokens.textMutedOnDark,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: AppTokens.textOnDark,
                  fontWeight: FontWeight.w800,
                  height: 1.1,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: AppTokens.textMutedOnDark,
                  fontWeight: FontWeight.w600,
                  height: 1.2,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ---------------- FAB ----------------

class _RefFab extends StatelessWidget {
  const _RefFab();

  @override
  Widget build(BuildContext context) {
    // Reference is a small rounded-rect pill with glow.
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: AppTokens.accentGreen.withValues(alpha: 0.20),
              blurRadius: 26,
              spreadRadius: 3,
            ),
          ],
        ),
        child: Frosted(
          radius: 22,
          padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 14),
          blurSigma: 12,
          borderAlpha: 0.06,
          tint: const Color(0xFF0F1415),
          child: const Icon(Icons.add, size: 22, color: AppTokens.accentGreen),
        ),
      ),
    );
  }
}
